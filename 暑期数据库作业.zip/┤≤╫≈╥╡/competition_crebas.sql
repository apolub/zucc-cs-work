/*==============================================================*/
/* DBMS name:      Sybase SQL Anywhere 12                       */
/* Created on:     2022/8/28 9:17:38                            */
/*==============================================================*/


if exists(select 1 from sys.sysforeignkey where role='FK_APPLICAT_1��2_STUDENT_') then
    alter table Application_form
       delete foreign key FK_APPLICAT_1��2_STUDENT_
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_EVENT_IN_RELATIONS_COMPETIT') then
    alter table event_info
       delete foreign key FK_EVENT_IN_RELATIONS_COMPETIT
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_EVENT_IN_RELATIONS_GROUP_') then
    alter table event_info
       delete foreign key FK_EVENT_IN_RELATIONS_GROUP_
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_GROUP__1��1_GROUP_IN') then
    alter table group_
       delete foreign key FK_GROUP__1��1_GROUP_IN
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_GROUP_IN_RELATIONS_GROUP_') then
    alter table group_info
       delete foreign key FK_GROUP_IN_RELATIONS_GROUP_
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_STUDENT__RELATIONS_APPLICAT') then
    alter table student_info
       delete foreign key FK_STUDENT__RELATIONS_APPLICAT
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_STUDENT__RELATIONS_GROUP_IN') then
    alter table student_info
       delete foreign key FK_STUDENT__RELATIONS_GROUP_IN
end if;

drop index if exists Application_form.1��2_FK;

drop index if exists Application_form.Application_form_PK;

drop table if exists Application_form;

drop index if exists competition_info.competition_info_PK;

drop table if exists competition_info;

drop index if exists event_info.Relationship_5_FK;

drop index if exists event_info.Relationship_3_FK;

drop index if exists event_info.event_info_PK;

drop table if exists event_info;

drop index if exists group_.1��1_FK;

drop index if exists group_.group_PK;

drop table if exists group_;

drop index if exists group_info.Relationship_2_FK;

drop index if exists group_info.group_info_PK;

drop table if exists group_info;

drop index if exists manager_info.manager_info_PK;

drop table if exists manager_info;

drop index if exists student_info.Relationship_4_FK;

drop index if exists student_info.relationship1_FK;

drop index if exists student_info.student_info_PK;

drop table if exists student_info;

/*==============================================================*/
/* Table: Application_form                                      */
/*==============================================================*/
create table Application_form 
(
   competition_id       integer                        not null,
   id                   integer                        null,
   group_id             integer                        null,
   join_time            date                           null,
   registration_status  varchar(50)                    null,
   Awardwinning_rating  varchar(20)                    null,
   constraint PK_APPLICATION_FORM primary key (competition_id)
);

/*==============================================================*/
/* Index: Application_form_PK                                   */
/*==============================================================*/
create unique index Application_form_PK on Application_form (
competition_id ASC
);

/*==============================================================*/
/* Index: 1��2_FK                                                */
/*==============================================================*/
create index 1��2_FK on Application_form (
id ASC
);

/*==============================================================*/
/* Table: competition_info                                      */
/*==============================================================*/
create table competition_info 
(
   competition_id       integer                        not null,
   compe_name           varchar(50)                    null,
   year                 date                           null,
   Held_within_the      varchar(20)                    null,
   "Subordinate_to_the games" varchar(30)                    null,
   Registration_start_time date                           null,
   Closing_time_of_egistration date                           null,
   Date_of_the_game     date                           null,
   contacts             varchar(20)                    null,
   website              varchar(150)                   null,
   constraint PK_COMPETITION_INFO primary key (competition_id)
);

/*==============================================================*/
/* Index: competition_info_PK                                   */
/*==============================================================*/
create unique index competition_info_PK on competition_info (
competition_id ASC
);

/*==============================================================*/
/* Table: event_info                                            */
/*==============================================================*/
create table event_info 
(
   event_id             integer                        not null,
   group_id             integer                        null,
   competition_id       integer                        null,
   event_name           varchar(30)                    null,
   principal            varchar(20)                    null,
   Affiliated_colleges  varchar(80)                    null,
   level                varchar(20)                    null,
   constraint PK_EVENT_INFO primary key (event_id)
);

/*==============================================================*/
/* Index: event_info_PK                                         */
/*==============================================================*/
create unique index event_info_PK on event_info (
event_id ASC
);

/*==============================================================*/
/* Index: Relationship_3_FK                                     */
/*==============================================================*/
create index Relationship_3_FK on event_info (
competition_id ASC
);

/*==============================================================*/
/* Index: Relationship_5_FK                                     */
/*==============================================================*/
create index Relationship_5_FK on event_info (
group_id ASC
);

/*==============================================================*/
/* Table: group_                                                */
/*==============================================================*/
create table group_ 
(
   group_id             integer                        not null,
   student_id           integer                        null,
   group_name           varchar(30)                    null,
   group_number         integer                        null,
   constraint PK_GROUP_ primary key (group_id)
);

/*==============================================================*/
/* Index: group_PK                                              */
/*==============================================================*/
create unique index group_PK on group_ (
group_id ASC
);

/*==============================================================*/
/* Index: 1��1_FK                                                */
/*==============================================================*/
create index 1��1_FK on group_ (
student_id ASC
);

/*==============================================================*/
/* Table: group_info                                            */
/*==============================================================*/
create table group_info 
(
   student_id           integer                        not null,
   gro_group_id         integer                        null,
   team_leader          varchar(20)                    null,
   Join_contest         varchar(20)                    null,
   group_id             char(10)                       null,
   constraint PK_GROUP_INFO primary key (student_id)
);

/*==============================================================*/
/* Index: group_info_PK                                         */
/*==============================================================*/
create unique index group_info_PK on group_info (
student_id ASC
);

/*==============================================================*/
/* Index: Relationship_2_FK                                     */
/*==============================================================*/
create index Relationship_2_FK on group_info (
gro_group_id ASC
);

/*==============================================================*/
/* Table: manager_info                                          */
/*==============================================================*/
create table manager_info 
(
   id                   integer                        not null,
   name                 varchar(20)                    null,
   password             varchar(20)                    null,
   constraint PK_MANAGER_INFO primary key (id)
);

/*==============================================================*/
/* Index: manager_info_PK                                       */
/*==============================================================*/
create unique index manager_info_PK on manager_info (
id ASC
);

/*==============================================================*/
/* Table: student_info                                          */
/*==============================================================*/
create table student_info 
(
   id                   integer                        not null,
   competition_id       integer                        not null,
   student_id           integer                        null,
   name                 varchar(20)                    null,
   password             varchar(20)                    null,
   grade                varchar(20)                    null,
   major                varchar(20)                    null,
   number               integer                        null,
   constraint PK_STUDENT_INFO primary key (id)
);

/*==============================================================*/
/* Index: student_info_PK                                       */
/*==============================================================*/
create unique index student_info_PK on student_info (
id ASC
);

/*==============================================================*/
/* Index: relationship1_FK                                      */
/*==============================================================*/
create index relationship1_FK on student_info (
student_id ASC
);

/*==============================================================*/
/* Index: Relationship_4_FK                                     */
/*==============================================================*/
create index Relationship_4_FK on student_info (
competition_id ASC
);

alter table Application_form
   add constraint FK_APPLICAT_1��2_STUDENT_ foreign key (id)
      references student_info (id)
      on update restrict
      on delete restrict;

alter table event_info
   add constraint FK_EVENT_IN_RELATIONS_COMPETIT foreign key (competition_id)
      references competition_info (competition_id)
      on update restrict
      on delete restrict;

alter table event_info
   add constraint FK_EVENT_IN_RELATIONS_GROUP_ foreign key (group_id)
      references group_ (group_id)
      on update restrict
      on delete restrict;

alter table group_
   add constraint FK_GROUP__1��1_GROUP_IN foreign key (student_id)
      references group_info (student_id)
      on update restrict
      on delete restrict;

alter table group_info
   add constraint FK_GROUP_IN_RELATIONS_GROUP_ foreign key (gro_group_id)
      references group_ (group_id)
      on update restrict
      on delete restrict;

alter table student_info
   add constraint FK_STUDENT__RELATIONS_APPLICAT foreign key (competition_id)
      references Application_form (competition_id)
      on update restrict
      on delete restrict;

alter table student_info
   add constraint FK_STUDENT__RELATIONS_GROUP_IN foreign key (student_id)
      references group_info (student_id)
      on update restrict
      on delete restrict;

