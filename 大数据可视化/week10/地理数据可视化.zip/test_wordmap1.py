# 首先导入basemap和matplotlib两个包，两者都是必要的。
from mpl_toolkits.basemap import Basemap
import matplotlib.pyplot as plt
# 新建第一个地图
map = Basemap()
# 在使用 Basemap 类创建地图时具有许多选项。
# 在没有传递任何选项的 情况下，地图具有以经度 =0 和纬度 = 0 为中心的 Plate Carrée 投影(等距圆柱投影)。

# 绘制海岸线
map.drawcoastlines()
# 如果使用单独的python程序（.py文件），需要下面这句话才能看到图
plt.show()