import pandas as pd
import plotly.express as px
import plotly
internet_usage_df = pd.read_csv('D:\\py\\data\\share-of-individuals-using-the-internet.csv')
internet_usage_2016 = internet_usage_df.query("Year==2016")


#Add title text to the choropleth map

fig = px.choropleth(internet_usage_2016,
                    locations="Code",
                    color="Individuals using the Internet (% of population)", # column by which to color-code
                    hover_name="Country", # column to display in hover information                    color_continuous_scale=px.colors.sequential.Plasma)
                   )
fig.update_layout(
    # add a title text for the plot
    title_text = 'Internet usage across the world (% population) - 2016'
)

fig.show()
plotly.offline.plot(fig, filename='Internet usage across the world (% population) flat- 2016.html')

#Set the projection type to natural earth:

fig = px.choropleth(internet_usage_2016,
                    locations="Code",
                    color="Individuals using the Internet (% of population)", # column by which to color-code
                    hover_name="Country", # column to display in hover information
                    color_continuous_scale=px.colors.sequential.Plasma)

fig.update_layout(
    # add a title text for the plot
    title_text = 'Internet usage across the world (% population) - 2016',
    # set projection style for the plot
    geo = dict(projection={'type':'natural earth'}) # by default, projection type is set to 'equirectangular'
)

fig.show()
plotly.offline.plot(fig, filename='Internet usage across the world (% population) natural- 2016.html')

#Set geo_scope to asia in the update_layout function:

fig = px.choropleth(internet_usage_2016,
                    locations="Code",
                    color="Individuals using the Internet (% of population)", # column by which to color-code
                    hover_name="Country", # column to display in hover information
                    color_continuous_scale=px.colors.sequential.Plasma)

fig.update_layout(
    # add a title text for the plot
    title_text = 'Internet usage across the Asia Continent (% population) - 2016',
    geo_scope = 'asia' # can be set to north america | south america | africa | asia | europe | usa
)

fig.show()
plotly.offline.plot(fig, filename='Internet usage across the Asia Continent (% population) - 2016.html')



