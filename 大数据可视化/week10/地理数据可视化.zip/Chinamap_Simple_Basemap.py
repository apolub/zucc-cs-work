from mpl_toolkits.basemap import Basemap
import matplotlib.pyplot as plt
# plt.figure(figsize=(10, 6))
# llcrnrlon：The lower left corner geographical longitude
# llcrnrlat：The lower left corner geographical latitude
# urcrnrlon： The upper right corner geographical longitude
# urcrnrlat	：The upper right corner geographical latitude
# projection='lcc'，lcc=Lambert Conformal兰伯特正形
# lon_0	The： longitude of the center of the map
# lat_0	The： latitude of the center of the map
# 中国最东端：东经135度2分30秒 黑龙江和乌苏里江交汇处；最西端：东经73度40分 帕米尔高原乌兹别里山口（乌恰县）；最南端：北纬3度52分 南沙群岛曾母暗沙；最北端：北纬53度33分 漠河以北黑龙江主航道（漠河)。
m =  m = Basemap(llcrnrlon=77, llcrnrlat=14, urcrnrlon=140, urcrnrlat=51, projection='lcc', lat_1=33, lat_2=45, lon_0=100)
m.drawcountries(linewidth=2)
m.drawcoastlines()
plt.show()