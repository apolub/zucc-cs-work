
import pandas as pd
import plotly.graph_objects as go
import plotly

us_airports_df = pd.read_csv('D:\\py\\data\\airports.csv')
us_airports_df.head()

#Now Let’s load the file containing flight records.
new_year_2015_flights_df = pd.read_csv('D:\\py\\data\\new_year_day_2015_delayed_flights.csv')
new_year_2015_flights_df.head()

#We can generate a scatter plot on the US map to indicate the locations of all airports in our dataset, using the graph_objects module.

fig = go.Figure()

fig.add_trace(go.Scattergeo(
    locationmode = 'USA-states',
    lon = us_airports_df['LONGITUDE'],
    lat = us_airports_df['LATITUDE'],
    hoverinfo = 'text',
    text = us_airports_df['AIRPORT'],
    mode = 'markers',
    marker = dict(size = 5,color = 'black')))

fig.update_layout(
    title_text = 'Airports in USA',
    showlegend = False,
    geo = go.layout.Geo(
        scope = 'usa'
    ),
)

fig.show()
plotly.offline.plot(fig, filename='Airports in USA.html')

#Along with the source and destination airports for each flight, we need to have the longitude and latitude information of the corresponding airports. To do this, we need to merge the DataFrames containing airport and flight data. Let’s first merge to obtain longitude and latitudes for the origin airports of all flights.
# merge the DataFrames on origin airport codes
new_year_2015_flights_df = new_year_2015_flights_df.merge(us_airports_df[['IATA_CODE','LATITUDE','LONGITUDE']], \
                                                          left_on='ORIGIN_AIRPORT', \
                                                          right_on='IATA_CODE', \
                                                          how='inner')

# drop the duplicate column containing airport code
new_year_2015_flights_df.drop(columns=['IATA_CODE'],inplace=True)

# rename the latitude and longitude columns to reflect that they correspond to the origin airport
new_year_2015_flights_df.rename(columns={"LATITUDE":"ORIGIN_AIRPORT_LATITUDE", "LONGITUDE":"ORIGIN_AIRPORT_LONGITUDE"},inplace=True)
new_year_2015_flights_df.head()

#Now, we will perform a similar merging to get the latitude, longitude data for destination airports of all flights.
# merge the DataFrames on desintation airport codes
new_year_2015_flights_df = new_year_2015_flights_df.merge(us_airports_df[['IATA_CODE','LATITUDE','LONGITUDE']], \
                                                          left_on='DESTINATION_AIRPORT', \
                                                          right_on='IATA_CODE', \
                                                          how='inner')
# drop the duplicate column containing airport code
new_year_2015_flights_df.drop(columns=['IATA_CODE'],inplace=True)

# rename the latitude and longitude columns to reflect that they correspond to the destination airport
new_year_2015_flights_df.rename(columns={'LATITUDE':'DESTINATION_AIRPORT_LATITUDE', 'LONGITUDE':'DESTINATION_AIRPORT_LONGITUDE'},inplace=True)
new_year_2015_flights_df.head()

#Now, we will draw our line plots -- for each flight, we need to draw a line between the origin and destination airport. This is done by providing the latitude and longitude values of destination and origin airports to the lonand lat parameters of Scattergeo and setting mode to 'lines' instead of 'markers'. Also, notice that we are using another add_trace function here.
#  It may take a few minutes for the plot to show the flight routes.
for i in range(len(new_year_2015_flights_df)):
    fig.add_trace(
        go.Scattergeo(
            locationmode = 'USA-states',
            lon = [new_year_2015_flights_df['ORIGIN_AIRPORT_LONGITUDE'][i], new_year_2015_flights_df['DESTINATION_AIRPORT_LONGITUDE'][i]],
            lat = [new_year_2015_flights_df['ORIGIN_AIRPORT_LATITUDE'][i], new_year_2015_flights_df['DESTINATION_AIRPORT_LATITUDE'][i]],
            mode = 'lines',
            line = dict(width = 1,color = 'red')
        )
    )
    
fig.update_layout(
    title_text = 'Delayed flight on Jan 1, 2015 in USA',
    showlegend = False,
    geo = go.layout.Geo(
        scope = 'usa'
    ),
)
  
fig.show()

plotly.offline.plot(fig, filename='Delayed flight on Jan 1, 2015 in USA.html')
