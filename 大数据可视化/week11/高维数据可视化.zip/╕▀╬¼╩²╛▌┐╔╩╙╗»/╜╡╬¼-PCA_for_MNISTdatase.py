import numpy as np
from struct import unpack
import gzip
import sklearn
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt


def __read_image(path):
    with gzip.open(path, 'rb') as f:
        magic, num, rows, cols = unpack('>4I', f.read(16))
        img=np.frombuffer(f.read(), dtype=np.uint8).reshape(num, 28*28)
    return img

def __read_label(path):
    with gzip.open(path, 'rb') as f:
        magic, num = unpack('>2I', f.read(8))
        lab = np.frombuffer(f.read(), dtype=np.uint8)
        # print(lab[1])
    return lab
    
def __normalize_image(image):
    img = image.astype(np.float32) / 255.0
    return img

def __one_hot_label(label):
    lab = np.zeros((label.size, 10))
    for i, row in enumerate(lab):
        row[label[i]] = 1
    return lab

def load_mnist(x_train_path, y_train_path, x_test_path, y_test_path, normalize=True, one_hot=True):
    
    
    image = {
        'train' : __read_image(x_train_path),
        'test'  : __read_image(x_test_path)
    }

    label = {
        'train' : __read_label(y_train_path),
        'test'  : __read_label(y_test_path)
    }
    
    if normalize:
        for key in ('train', 'test'):
            image[key] = __normalize_image(image[key])

    if one_hot:
        for key in ('train', 'test'):
            label[key] = __one_hot_label(label[key])

    return (image['train'], label['train']), (image['test'], label['test'])

x_train_path='./Mnist/train-images-idx3-ubyte.gz'
y_train_path='./Mnist/train-labels-idx1-ubyte.gz'
x_test_path='./Mnist/t10k-images-idx3-ubyte.gz'
y_test_path='./Mnist/t10k-labels-idx1-ubyte.gz'
(x_train,y_train),(x_test,y_test)=load_mnist(x_train_path, y_train_path, x_test_path, y_test_path,one_hot=False)

print("train_images info:", x_train.shape, x_train.shape[0],x_train.shape[1])
print("train_labels info:", y_train.shape, y_train.shape[0])
#print("test_images info:", x_test.shape, x_test.shape[0], x_test.shape[1],x_test.shape[2])
#print("test_labels info:", y_test.shape, y_test.shape[0])

X_train = x_train [0:10000]
y_train = y_train [0:10000]
n_samples, n_features = X_train.shape

print(n_features)
print(n_samples)

pca =PCA(n_components=2)
pca.fit(X_train)
X_pca = pca.fit_transform(X_train)


n_samples, n_features = X_pca.shape
print(n_features)
print(n_samples)

plt.figure(figsize=(10,10))
plt.scatter(X_pca[y_train==0, 0], X_pca[y_train==0, 1], color='blue', alpha=0.5,label='0', s=9, lw=2)
plt.scatter(X_pca[y_train==1, 0], X_pca[y_train==1, 1], color='purple', alpha=0.5,label='1',s=9, lw=2)
plt.scatter(X_pca[y_train==2, 0], X_pca[y_train==2, 1], color='yellow', alpha=0.5,label='2',s=9, lw=2)
plt.scatter(X_pca[y_train==3, 0], X_pca[y_train==3, 1], color='black', alpha=0.5,label='3',s=9, lw=2)
plt.scatter(X_pca[y_train==4, 0], X_pca[y_train==4, 1], color='gray', alpha=0.5,label='4',s=9, lw=2)
plt.scatter(X_pca[y_train==5, 0], X_pca[y_train==5, 1], color='turquoise', alpha=0.5,label='5',s=9, lw=2)
plt.scatter(X_pca[y_train==6, 0], X_pca[y_train==6, 1], color='red', alpha=0.5,label='6',s=9, lw=2)
plt.scatter(X_pca[y_train==7, 0], X_pca[y_train==7, 1], color='green', alpha=0.5,label='7',s=9, lw=2)
plt.scatter(X_pca[y_train==8, 0], X_pca[y_train==8, 1], color='violet', alpha=0.5,label='8',s=9, lw=2)
plt.scatter(X_pca[y_train==9, 0], X_pca[y_train==9, 1], color='orange', alpha=0.5,label='9',s=9, lw=2)

plt.show()