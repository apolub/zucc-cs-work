# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt 
import pandas as pd
import seaborn as sns
from plotnine.data import mtcars
from sklearn.preprocessing import scale

sns.set_style("white")
sns.set_context("notebook", font_scale=1.5,
                rc={'axes.labelsize': 17, 'legend.fontsize':17, 
                    'xtick.labelsize': 15,'ytick.labelsize': 10})

df=mtcars.set_index('name')
df.loc[:,:] = scale(df.values )

#------------------------------- (a)热力图------------------------------------------------------
fig=plt.figure(figsize=(7, 7),dpi=80)
sns.heatmap(df, center=0, cmap="RdYlBu_r",
               linewidths=.15,linecolor='k')
#sns.set()
#plt.savefig('heatmap2.png')

#--------------------------------(b)带层次聚类的热力图.-----------------------------------------------------------
sns.clustermap(df, center=0, cmap="RdYlBu_r",
               linewidths=.15,linecolor='k', figsize=(8, 8))


