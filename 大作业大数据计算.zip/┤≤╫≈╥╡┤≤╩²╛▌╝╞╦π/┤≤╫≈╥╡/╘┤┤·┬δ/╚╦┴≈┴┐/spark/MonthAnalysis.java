import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.sql.*;

import java.util.ArrayList;
import java.util.List;

import static org.apache.spark.sql.functions.*;

public class MonthAnalysis {
    public static void main(String[] args) {
        // 创建 SparkSession
        SparkSession spark = SparkSession.builder()
                .appName("Data Analysis")
                .master("local")
                .getOrCreate();

        // 读取 csv文件
        Dataset<Row> museumData = spark.read()
                .format("csv")
                .option("encoding","gbk")
                .option("useHeader","true")
                .option("header", "true")
                .load("C:\\Users\\win\\IdeaProjects\\sparktest\\testxlsx\\output2.csv")
                .drop("场馆介绍")
                .withColumn("日期", functions.to_date(functions.col("预约到馆时期"), "yyyy/M/d"))
                .withColumn("年份", functions.year(functions.col("日期")))
                .withColumn("月份", functions.month(functions.col("日期")))
                .withColumn("星期几", functions.date_format(functions.col("日期"), "EEEE"));

        //对星期几进行过滤
        Dataset<Row> weekendData = museumData.filter(
                functions.col("星期几").isin("Saturday", "Sunday"));

        //输出的处理
        Dataset<Row> whyError = museumData.na().fill("1", new String[]{"随同人员年龄", "随同人员性别", "随同人员姓名", "随同人员电话"})
                .withColumn("参观人数", museumData.col("参观人数").cast("integer"));

        // 选择输出的内容
        Dataset<Row> sortedData = whyError.select("月份", "博物馆名称","参观人数")
                .groupBy("月份","博物馆名称")
                .agg(functions.sum(whyError.col("参观人数")).alias("参观人数总计"))
                .orderBy("月份","博物馆名称")
                .filter(functions.col("博物馆名称").isNotNull());

        sortedData.show(100);

//        sortedData.coalesce(1).write()
//                .format("csv")
//                .option("encoding", "gbk")
//                .option("header", "true").csv("MonthPeopleCount.csv");
//        // 停止 SparkSession
        spark.stop();

        // 停止 SparkSession
        spark.stop();

    }
}
