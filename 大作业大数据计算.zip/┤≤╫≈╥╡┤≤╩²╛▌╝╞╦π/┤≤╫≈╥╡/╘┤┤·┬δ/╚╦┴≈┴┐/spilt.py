import csv
import json

# 打开CSV文件
with open('gy.csv', 'r', encoding='gbk') as file:
    reader = csv.DictReader(file)
    rows = list(reader)

# 转换数据
new_rows = []
for row in rows:
    companions = row['随同人员']
    if companions:
        companions = json.loads(companions)
    else:
        companions = [{}]  # 添加一个空字典以保留空的随行列表

    for companion in companions:
        new_row = dict(row)  # 复制原始行数据

        # 提取属性列值
        age = companion.get('age', '')
        gender = companion.get('gender', '')
        name = companion.get('name', '')
        phone = companion.get('phone', '')

        # 添加新的属性列
        new_row['随同人员年龄'] = age
        new_row['随同人员性别'] = gender
        new_row['随同人员姓名'] = name
        new_row['随同人员电话'] = phone

        new_rows.append(new_row)

# 写入新的CSV文件
fieldnames = reader.fieldnames  # 列标题
fieldnames.extend(['随同人员年龄', '随同人员性别', '随同人员姓名', '随同人员电话'])  # 添加新的属性列

with open('output.csv', 'w', encoding='utf-8', newline='') as file:
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(new_rows)