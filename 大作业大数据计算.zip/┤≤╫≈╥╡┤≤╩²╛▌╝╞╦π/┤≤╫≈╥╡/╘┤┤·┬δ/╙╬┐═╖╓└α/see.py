import plotly
import pymysql
import pandas as pd
import plotly.graph_objs as pg


def bar_chart(host, port, user, passwd, dbname, charset,output_path):
    try:
        conn = pymysql.Connection(
            host=host,
            port=port,
            user=user,
            passwd=passwd,
            db=dbname,
            charset=charset
        )
        cur1 = conn.cursor()
        cur1.execute("select * from ads_guiyang_museum_analyse WHERE use_status LIKE '已使用';")
        # cursor对象使用MySQL查询字符串执行查询，返回一个包含多个元组的元组——每行对应一个元组
        rows1 = cur1.fetchall()
        # print(rows)

        # 使用Pandas的DataFrame来处理每一行要比使用一个包含元组的元组方便
        # 下面的Python代码片段将所有行转化为DataFrame实例
        df1 = pd.DataFrame([[ij for ij in i] for i in rows1])
        df1.rename(columns={0: 'view_persons', 1: 'use_status', 2: 'cnt'}, inplace=True)
        print(df1)
        # df = df.sort(['LifeExpectancy'], ascending=[1])

        cur2 = conn.cursor()
        cur2.execute("select * from ads_guiyang_museum_analyse WHERE use_status LIKE '已过期';")
        # cursor对象使用MySQL查询字符串执行查询，返回一个包含多个元组的元组——每行对应一个元组
        rows2 = cur2.fetchall()
        # print(rows)

        # 使用Pandas的DataFrame来处理每一行要比使用一个包含元组的元组方便
        # 下面的Python代码片段将所有行转化为DataFrame实例
        df2 = pd.DataFrame([[ij for ij in i] for i in rows2])
        df2.rename(columns={0: 'view_persons', 1: 'use_status', 2: 'cnt'}, inplace=True)
        print(df2)

        cur3 = conn.cursor()
        cur3.execute("select * from ads_guiyang_museum_analyse WHERE use_status LIKE '已取消';")
        # cursor对象使用MySQL查询字符串执行查询，返回一个包含多个元组的元组——每行对应一个元组
        rows3 = cur3.fetchall()
        # print(rows)

        # 使用Pandas的DataFrame来处理每一行要比使用一个包含元组的元组方便
        # 下面的Python代码片段将所有行转化为DataFrame实例
        df3 = pd.DataFrame([[ij for ij in i] for i in rows3])
        df3.rename(columns={0: 'view_persons', 1: 'use_status', 2: 'cnt'}, inplace=True)
        print(df3)

        date_price = pg.Bar(x=df1["view_persons"], y=df1["cnt"], name='已使用')
        date_quantity = pg.Bar(x=df2["view_persons"], y=df2["cnt"], name='已过期')
        date_amount = pg.Bar(x=df3["view_persons"], y=df3["cnt"], name='已取消')
        data = [date_price, date_quantity, date_amount]

        layout = pg.Layout(barmode='group', title="预约人数和到场关系")
        fig = pg.Figure(data=data, layout=layout)
        plotly.offline.plot(fig, filename=output_path)

    finally:
        if conn:
            conn.close()


if __name__ == '__main__':
    output_path = "D:/AAAzuoye/bar.html"
    bar_chart("localhost", 3306, "root", "123456", "data_analyse", "utf8", output_path)