package com.colin.spark.scala.project

import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

import java.util.Properties

/**
 * 分析参观人数和核销状态之间的关系
 * 几个人的时候 核销状态分布情况
 */
object GuiYangReservation {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .master("local[6]")
      .appName("app")
      .getOrCreate()

    val dataframe: DataFrame = spark.read
      .option("delimiter", ",")
      .option("header", "true")
      .option("inferSchema", "true")
      .option("sep", ",")
      .option("encoding","gbk")
      .csv("D:\\贵阳博物馆预约数据分析\\spark1\\file\\1_format.csv")
//      .csv("D:\\贵阳博物馆预约数据分析\\spark1\\file\\GY.csv")

    dataframe.createTempView("guiyang_reservation_view1")
    var sql =
      """
        |select `用户ID` as user_id,
        |`性别` as sex,
        |`年龄` as age,
        |`参观人数` as view_persons,
        |`预约到馆时间` as reservation_time,
        |`核销状态` as use_status,
        |`博物馆ID` as museum_id,
        |`博物馆名称` as museum_name,
        |`场馆介绍` as museum_brief
        | from guiyang_reservation_view1
        |""".stripMargin
    spark.sql(sql).createTempView("guiyang_reservation_view2")
    val result = spark.sql(
      """
      SELECT sex, museum_name, COUNT(*) AS cnt
      FROM guiyang_reservation_view2
      GROUP BY museum_name, sex
      """.stripMargin)
    result.show()
    val properties: Properties = new Properties()
    properties.setProperty("user", "root")
    properties.setProperty("password", "123456")
    properties.setProperty("driver", "com.mysql.cj.jdbc.Driver")
    properties.setProperty("numPartitions", "10")
    result.write.mode(SaveMode.Overwrite)
      .jdbc("jdbc:mysql://localhost:3306/data_analyse?useUnicode=true&characterEncoding=UTF-8&allowMultiQueries=true&autoReconnect=true&useSSL=false&rewriteBatchedStatements=true&serverTimezone=Asia/Shanghai",
        "ads_guiyang_museum_analyse0", properties)
  }
}
