INSERT INTO `ads_guiyang_museum_analyse0` VALUES ('男', '贵州省地质博物馆', 55496);
INSERT INTO `ads_guiyang_museum_analyse0` VALUES ('男', '贵州省博物馆', 126106);
INSERT INTO `ads_guiyang_museum_analyse0` VALUES ('女', '贵州省地质博物馆', 82216);
INSERT INTO `ads_guiyang_museum_analyse0` VALUES ('女', '贵州省博物馆', 169527);
