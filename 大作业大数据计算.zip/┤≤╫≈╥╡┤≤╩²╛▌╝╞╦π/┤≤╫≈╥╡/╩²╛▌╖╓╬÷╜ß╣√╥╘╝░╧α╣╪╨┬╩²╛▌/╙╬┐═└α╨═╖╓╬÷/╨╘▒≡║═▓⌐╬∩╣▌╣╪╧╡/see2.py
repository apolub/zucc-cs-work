import plotly
import pymysql
import pandas as pd
import plotly.graph_objs as pg


def bar_chart(host, port, user, passwd, dbname, charset,output_path):
    try:
        conn = pymysql.Connection(
            host=host,
            port=port,
            user=user,
            passwd=passwd,
            db=dbname,
            charset=charset
        )
        cur1 = conn.cursor()
        cur1.execute("select * from ads_guiyang_museum_analyse0 WHERE sex LIKE '男';")
        # cursor对象使用MySQL查询字符串执行查询，返回一个包含多个元组的元组——每行对应一个元组
        rows1 = cur1.fetchall()
        # print(rows)

        # 使用Pandas的DataFrame来处理每一行要比使用一个包含元组的元组方便
        # 下面的Python代码片段将所有行转化为DataFrame实例
        df1 = pd.DataFrame([[ij for ij in i] for i in rows1])
        df1.rename(columns={0: 'sex', 1: 'museum_name', 2: 'cnt'}, inplace=True)
        print(df1)
        # df = df.sort(['LifeExpectancy'], ascending=[1])

        cur2 = conn.cursor()
        cur2.execute("select * from ads_guiyang_museum_analyse0 WHERE sex LIKE '女';")
        # cursor对象使用MySQL查询字符串执行查询，返回一个包含多个元组的元组——每行对应一个元组
        rows2 = cur2.fetchall()
        # print(rows)

        # 使用Pandas的DataFrame来处理每一行要比使用一个包含元组的元组方便
        # 下面的Python代码片段将所有行转化为DataFrame实例
        df2 = pd.DataFrame([[ij for ij in i] for i in rows2])
        df2.rename(columns={0: 'sex', 1: 'museum_name', 2: 'cnt'}, inplace=True)
        print(df2)


        date1 = pg.Bar(x=df1["museum_name"], y=df1["cnt"], name='男')
        date2 = pg.Bar(x=df2["museum_name"], y=df2["cnt"], name='女')
        data = [date1, date2]

        layout = pg.Layout(barmode='group', title="不同性别对不同博物馆的偏好")
        fig = pg.Figure(data=data, layout=layout)
        plotly.offline.plot(fig, filename=output_path)

    finally:
        if conn:
            conn.close()


if __name__ == '__main__':
    output_path = "D:/AAAzuoye/1.html"
    bar_chart("localhost", 3306, "root", "123456", "data_analyse", "utf8", output_path)