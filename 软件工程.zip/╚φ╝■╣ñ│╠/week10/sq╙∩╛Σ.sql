drop table if exists Comments;

drop table if exists Dish;

drop table if exists Record;

drop table if exists Restaurant;

drop table if exists Stores;

drop table if exists Users;

/*==============================================================*/
/* Table: Comments                                              */
/*==============================================================*/
create table Comments 
(
   Commentid            integer                        not null,
   Dishid               integer                        null,
   Recordid             integer                        null,
   Userid               integer                        null,
   dishlevel            varchar(20)                    null,
   content              varchar(300)                   null,
   constraint PK_COMMENTS primary key (Commentid)
);



/*==============================================================*/
/* Table: Dish                                                  */
/*==============================================================*/
create table Dish 
(
   Dishid               integer                        not null,
   Commentid            integer                        null,
   Storesid             integer                        null,
   Recordid             integer                        null,
   Dishname             varchar(30)                    null,
   Storename            varchar(30)                    null,
   constraint PK_DISH primary key (Dishid)
);


/*==============================================================*/
/* Table: Record                                                */
/*==============================================================*/
create table Record 
(
   Recordid             integer                        not null,
   Userid               integer                        null,
   Commentid            integer                        null,
   Dishid               integer                        null,
   Dataandtime          timestamp                      null,
   constraint PK_RECORD primary key (Recordid)
);


/*==============================================================*/
/* Table: Restaurant                                            */
/*==============================================================*/
create table Restaurant 
(
   Restaurantid         integer                        not null,
   Restuatrantname      varchar(30)                    null,
   constraint PK_RESTAURANT primary key (Restaurantid)
);


/*==============================================================*/
/* Table: Stores                                                */
/*==============================================================*/
create table Stores 
(
   Storesid             integer                        not null,
   Restaurantid         integer                        null,
   Storesname           varchar(30)                    null,
   constraint PK_STORES primary key (Storesid)
);


/*==============================================================*/
/* Table: Users                                                 */
/*==============================================================*/
create table Users 
(
   Userid               integer                        not null,
   Username             varchar(20)                    null,
   UserTel              varchar(20)                    null,
   constraint PK_USERS primary key (Userid)
);

alter table Comments
   add constraint FK_COMMENTS_RELATIONS_USERS foreign key (Userid)
      references Users (Userid)
      on update restrict
      on delete restrict;

alter table Comments
   add constraint FK_COMMENTS_RELATIONS_RECORD foreign key (Recordid)
      references Record (Recordid)
      on update restrict
      on delete restrict;

alter table Comments
   add constraint FK_COMMENTS_RELATIONS_DISH foreign key (Dishid)
      references Dish (Dishid)
      on update restrict
      on delete restrict;

alter table Dish
   add constraint FK_DISH_RELATIONS_RECORD foreign key (Recordid)
      references Record (Recordid)
      on update restrict
      on delete restrict;

alter table Dish
   add constraint FK_DISH_RELATIONS_STORES foreign key (Storesid)
      references Stores (Storesid)
      on update restrict
      on delete restrict;

alter table Dish
   add constraint FK_DISH_RELATIONS_COMMENTS foreign key (Commentid)
      references Comments (Commentid)
      on update restrict
      on delete restrict;

alter table Record
   add constraint FK_RECORD_N_USERS foreign key (Userid)
      references Users (Userid)
      on update restrict
      on delete restrict;

alter table Record
   add constraint FK_RECORD_RELATIONS_COMMENTS foreign key (Commentid)
      references Comments (Commentid)
      on update restrict
      on delete restrict;

alter table Record
   add constraint FK_RECORD_RELATIONS_DISH foreign key (Dishid)
      references Dish (Dishid)
      on update restrict
      on delete restrict;

alter table Stores
   add constraint FK_STORES_RELATIONS_RESTAURA foreign key (Restaurantid)
      references Restaurant (Restaurantid)
      on update restrict
      on delete restrict;
