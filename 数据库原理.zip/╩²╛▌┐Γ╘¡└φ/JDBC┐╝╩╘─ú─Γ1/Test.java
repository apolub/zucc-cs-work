package cn.edu.zucc.test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.edu.zucc.tester.questions.q202101_01.BeanP;
import cn.edu.zucc.tester.questions.q202101_01.BeanS;
import cn.edu.zucc.tester.questions.q202101_01.Question202101_01;

public class Test extends Question202101_01{
	public String getServer() {return "http://10.66.55.76:80/t2021x";}
	public int getTestid(){return 17;}
	public  String getSno(){return "J04019";}
	public  String getKey(){return "fc82427080358ae760edd4b5b12a91ad1WrgbI0zx9XEXvPp43JIQV";}
	@Override
	public BeanP m001LoadP(String pno) {
		Connection conn=null;
		try {
			conn = DBUtil.getConnection();
			String sql = "select pno,pname,color,weight,total_count from p where pno = ?";
			java.sql.PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, pno);
			java.sql.ResultSet rs = pst.executeQuery();
			if(rs.next()) {
				BeanP p = new BeanP();
				p.setPno(rs.getString(1));
				p.setPname(rs.getString(2));
				p.setColor(rs.getString(3));
				p.setWeight(rs.getInt(4));
				p.setTotal_count(rs.getInt(5));
				return p;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<BeanS> m002ListCityS(String city) {
		List<BeanS> result=new ArrayList<>();
		Connection conn=null;
		try {
			conn = DBUtil.getConnection();
			String sql = "select sno,sname,city from s where city = ?";
			java.sql.PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, city);
			java.sql.ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				BeanS p = new BeanS();
				p.setSno(rs.getString(1));
				p.setSname(rs.getString(2));
				p.setCity(rs.getString(3));
				result.add(p);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public Map<String, Integer> m003LoadJTotalWeight() {
		//提取所有工程的编号及使用的零件的总重量
		Map<String, Integer> result = new HashMap<>();
		Connection conn=null;
		try {
			conn = DBUtil.getConnection();
			String sql = "select jno,sum(qty*weight) from p,spj where p.pno=spj.pno group by jno";
			java.sql.PreparedStatement pst = conn.prepareStatement(sql);
			java.sql.ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				result.put(rs.getString(1),rs.getInt(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public void m004add(String sno, String pno, String jno, int qty) {
		//添加供应信息，注意：供应表中已经存在相应的sno/pno/jno的数据时，应在原有数量基础上增加供应量
		//另外，应同时增加零件表中的总使用量
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			conn.setAutoCommit(false);
			String sql = "select qty from spj where sno = ? and pno = ? and jno=?";
			java.sql.PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, sno);
			pst.setString(2, pno);
			pst.setString(3, jno);
			java.sql.ResultSet rs = pst.executeQuery();
			if(!rs.next()) {
				pst.close();
				sql = "insert into spj(sno,pno,jno,qty) values(?,?,?,?)";
				pst=conn.prepareStatement(sql);
				pst.setString(1, sno);
				pst.setString(2, pno);
				pst.setString(3, jno);
				pst.setInt(4, qty);
				pst.executeUpdate();
			}else {
				pst.close();
				sql = "update spj set qty=qty+? where sno = ? and pno = ? and jno=?";
				pst=conn.prepareStatement(sql);
				pst.setInt(1, qty);
				pst.setString(2, sno);
				pst.setString(3, pno);
				pst.setString(4, jno);
				pst.executeUpdate();
			}
			pst.close();
			sql="update p set total_count=total_count+? where pno = ?";
			pst=conn.prepareStatement(sql);
			pst.setInt(1, qty);
			pst.setString(2, pno);
			pst.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		Test t=new Test();
		Connection conn=null;
		try{
			conn=DBUtil.getConnection();
		}catch(java.lang.Throwable ex){
			ex.printStackTrace();
			System.out.println("初始化失败");
			return;
		}
		int[] methods={1,2,3,4};
		for(int i=1;i<1000;i++) {
			t.checkAll(conn, methods);
			System.out.println(i);
		}

	}

	
	
	

}