package cn.edu.zucc.booklib;

import cn.edu.zucc.booklib.ui.FrmMain;
public class BookLibStarter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FrmMain();
	}

}
