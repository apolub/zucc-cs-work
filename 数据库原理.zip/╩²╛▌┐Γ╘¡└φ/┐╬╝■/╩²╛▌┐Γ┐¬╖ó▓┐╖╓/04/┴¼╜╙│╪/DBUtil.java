package cn.edu.zucc.booklib.util;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

public class DBUtil {
	private static final String jdbcUrl="jdbc:mysql://localhost:3306/booklib2020";
	private static final String dbUser="root";
	private static final String dbPwd="zucc";
	static{
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/*public static Connection getConnection() throws java.sql.SQLException{
		Connection conn= java.sql.DriverManager.getConnection(jdbcUrl, dbUser, dbPwd);
		System.out.println(conn);
		return conn;
	}*/
	
	private static List<ConnectionAgent> lst = new ArrayList<>();
	public static Connection getConnection()throws java.sql.SQLException{
		Connection c = null;
		if(lst.size()>0) c=lst.remove(0);
		if(c==null) {
			Connection conn= java.sql.DriverManager.getConnection(jdbcUrl, dbUser, dbPwd);
			c = new ConnectionAgent(conn);
		}
		return c;
	}
	public static void freeConnection(Connection c) {
		lst.add((ConnectionAgent) c);
	}
}
