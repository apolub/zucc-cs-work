package cn.edu.zucc.booklib.control;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.edu.zucc.booklib.model.Orders;
import cn.edu.zucc.booklib.util.BaseException;

public class OrdersManager {

	
	public static void main(String[] args) {

		//��ȷ��ѯ
		try{
			
			
		}catch(BaseException e){
			e.printStackTrace();
		}
		
		//ģ����ѯ
		try{
			
			
		}catch(BaseException e){
			e.printStackTrace();
		}
		
		
	}
}
