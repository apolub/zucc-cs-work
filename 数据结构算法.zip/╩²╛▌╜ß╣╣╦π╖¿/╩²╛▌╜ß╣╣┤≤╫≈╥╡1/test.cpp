#include<stdio.h>
int main()
{  
 	FILE *fin,*fout,*fcpp;
 	fin=fopen("10.in","r");
 	fout=fopen("10.out","w"); 
	if(fin==NULL){
 		return 0;
 }
 	char str[10000];
 	fgets(str,1000,fin);
 	fputs(str,fout);
	  
 
 	fclose(fin);
 	fclose(fout);
 	return 0; 
}
