采用gdk编码，请使用Dev-c++打开。
Sourse code files.cpp 为源代码
Sourse code files.exe 为可执行文件