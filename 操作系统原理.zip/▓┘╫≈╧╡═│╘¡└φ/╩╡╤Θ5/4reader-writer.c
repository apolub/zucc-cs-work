#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <sys/types.h>

#define READERCOUNT  5		
#define WRITERCOUNT  3		
#define PAPERSIZE  26     

static char paper[PAPERSIZE];        
unsigned short int write_index = 0; 
char ch = 'A';  					
sem_t rmutex,wmutex; 
int nReader = 0;


void *reader(void *args)
{
    int number =*((int *)args);
    int i;
    for(i = 0;i <10;i++){
		sem_wait(&rmutex);
       
        if (nReader == 0)
            sem_wait(&wmutex);
        ++ nReader;
        sem_post(&rmutex);
 
       
        printf("## reader %d was reading...\n", number);
        printf("text: %s\n", paper);sleep(1);
        printf("   reader %d end reading...\n\n", number);
 
        sem_wait(&rmutex);
        -- nReader;
       
        if (nReader == 0)
            sem_post(&wmutex);
        sem_post(&rmutex);
        sleep(1);
    }
    pthread_exit(NULL);
}
 

void *writer(void *args)
{
    int number =*((int *)args);
    int i;
    for(i = 0;i <9;i++){
        sem_wait(&wmutex);
        //start writing
        printf("++ writer %d was writing...%c\n", number,ch);
        paper[write_index] = ch;
		sleep(1);
        write_index = (write_index+1)%26;
        ch = ch+1;
        if (ch > 'Z') 		ch = 'A';
        printf("   writer %d end writing...\n\n", number);
        //end writing
        sem_post(&wmutex);
        sleep(1);
	} 
    pthread_exit(NULL);
}
 
int main()
{
	int i;    
	int rThdNum[READERCOUNT],wThdNum[WRITERCOUNT];
	pthread_t wthread[WRITERCOUNT];  
	pthread_t rthread[READERCOUNT];  
	sem_init(&rmutex, 0, 1);
	sem_init(&wmutex, 0, 1);

	for (i = 0; i < READERCOUNT; i++)
		rThdNum[i] = i;
	for (i = 0; i < WRITERCOUNT; i++)
		wThdNum[i] = i;

	for ( i = 0; i < READERCOUNT; ++i)
		pthread_create(&rthread[i], NULL, reader,(void *)&rThdNum[i]);
	for (i = 0; i <WRITERCOUNT; ++i)
		pthread_create(&wthread[i], NULL, writer,(void *)&wThdNum[i]);

	for (i = 0; i < READERCOUNT; ++i)
		pthread_join(rthread[i], NULL);
	for (i = 0; i < WRITERCOUNT; ++i)
        	pthread_join(wthread[i], NULL);
 }
