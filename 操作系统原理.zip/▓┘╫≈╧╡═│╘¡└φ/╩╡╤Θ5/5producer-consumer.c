#include <stdlib.h>  
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>  
#include <semaphore.h>  
#include <errno.h>  
#include <fcntl.h>  

#define NBUFF      5       
   
int nitems;  
  
int buff[NBUFF];
sem_t mutex,empty,full;

void *produce(void *arg); 
void *consume(void *arg); 
   
int main(int argc,char *argv[]) 
{ 
	pthread_t   tid_produce,tid_consume; 
	if(argc != 2) 
	{ 
		printf("usage: prodcons <#itmes>"); 
		exit(0); 
	} 
	nitems = atoi(argv[1]);  
	
	sem_init(&mutex,0,1);
	sem_init(&empty,0,NBUFF);
	sem_init(&full,0,0); 
	
	pthread_setconcurrency(2); 
	pthread_create(&tid_produce,NULL,produce,NULL); 
	pthread_create(&tid_consume,NULL,consume,NULL); 
	pthread_join(tid_produce,NULL); 
	pthread_join(tid_consume,NULL); 
	exit(0); 
} 
   
void *produce(void *arg) 
{ 
	int i; 
	printf("\nproduce is called.\n"); 
	for(i=0;i<nitems;i++) 
	{ 		
		sem_wait(&empty);	
		sem_wait(&mutex); 
		printf("\nproduced a new item %d:",i); 
		scanf("%d",&buff[i%NBUFF]);
		sleep(1);
		sem_post(&mutex);  
		sem_post(&full);  
	} 
	return NULL; 
} 
   
void *consume(void *arg) 
{ 
	int   i; 
	printf("\nconsumer is called.\n"); 
	for(i=0;i<nitems;i++) 
	{		
		sem_wait(&full);  
		sem_wait(&mutex); 	
		if(buff[i % NBUFF] != i) 
			printf("\nremoved %d item %d.",i,buff[i% NBUFF]); 
		sleep(1);
		sem_post(&mutex); 
		sem_post(&empty); 
	} 
	return NULL;
}
