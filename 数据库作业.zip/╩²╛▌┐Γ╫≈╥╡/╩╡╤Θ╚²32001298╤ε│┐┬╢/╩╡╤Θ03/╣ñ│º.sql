if exists(select 1 from sys.sysforeignkey where role='FK_制造_制造_原材料') then
    alter table 制造
       delete foreign key FK_制造_制造_原材料
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_制造_制造2_零件') then
    alter table 制造
       delete foreign key FK_制造_制造2_零件
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_存放1_存放1_零件') then
    alter table 存放1
       delete foreign key FK_存放1_存放1_零件
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_存放1_存放4_仓库') then
    alter table 存放1
       delete foreign key FK_存放1_存放4_仓库
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_存放2_存放2_原材料') then
    alter table 存放2
       delete foreign key FK_存放2_存放2_原材料
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_存放2_存放3_仓库') then
    alter table 存放2
       delete foreign key FK_存放2_存放3_仓库
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_组成_组成_产品') then
    alter table 组成
       delete foreign key FK_组成_组成_产品
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_组成_组成2_零件') then
    alter table 组成
       delete foreign key FK_组成_组成2_零件
end if;

drop index if exists 产品.产品_PK;

drop table if exists 产品;

drop index if exists 仓库.仓库_PK;

drop table if exists 仓库;

drop index if exists 制造.制造2_FK;

drop index if exists 制造.制造_FK;

drop index if exists 制造.制造_PK;

drop table if exists 制造;

drop index if exists 原材料.原材料_PK;

drop table if exists 原材料;

drop index if exists 存放1.存放4_FK;

drop index if exists 存放1.存放1_FK;

drop index if exists 存放1.存放1_PK;

drop table if exists 存放1;

drop index if exists 存放2.存放3_FK;

drop index if exists 存放2.存放2_FK;

drop index if exists 存放2.存放2_PK;

drop table if exists 存放2;

drop index if exists 组成.组成2_FK;

drop index if exists 组成.组成_FK;

drop index if exists 组成.组成_PK;

drop table if exists 组成;

drop index if exists 零件.零件_PK;

drop table if exists 零件;

/*==============================================================*/
/* Table: 产品                                                    */
/*==============================================================*/
create table 产品 
(
   产品号                  integer                        not null,
   产品名                  varchar(20)                    null,
   constraint PK_产品 primary key (产品号)
);

/*==============================================================*/
/* Index: 产品_PK                                                 */
/*==============================================================*/
create unique index 产品_PK on 产品 (
产品号 ASC
);

/*==============================================================*/
/* Table: 仓库                                                    */
/*==============================================================*/
create table 仓库 
(
   仓库号                  integer                        not null,
   仓库名                  varchar(30)                    null,
   constraint PK_仓库 primary key (仓库号)
);

/*==============================================================*/
/* Index: 仓库_PK                                                 */
/*==============================================================*/
create unique index 仓库_PK on 仓库 (
仓库号 ASC
);

/*==============================================================*/
/* Table: 制造                                                    */
/*==============================================================*/
create table 制造 
(
   原材料号                 integer                        not null,
   零件号                  integer                        not null,
   constraint PK_制造 primary key clustered (原材料号, 零件号)
);

/*==============================================================*/
/* Index: 制造_PK                                                 */
/*==============================================================*/
create unique clustered index 制造_PK on 制造 (
原材料号 ASC,
零件号 ASC
);

/*==============================================================*/
/* Index: 制造_FK                                                 */
/*==============================================================*/
create index 制造_FK on 制造 (
原材料号 ASC
);

/*==============================================================*/
/* Index: 制造2_FK                                                */
/*==============================================================*/
create index 制造2_FK on 制造 (
零件号 ASC
);

/*==============================================================*/
/* Table: 原材料                                                   */
/*==============================================================*/
create table 原材料 
(
   原材料号                 integer                        not null,
   原材料名                 varchar(30)                    null,
   类别                   varchar(20)                    null,
   constraint PK_原材料 primary key (原材料号)
);

/*==============================================================*/
/* Index: 原材料_PK                                                */
/*==============================================================*/
create unique index 原材料_PK on 原材料 (
原材料号 ASC
);

/*==============================================================*/
/* Table: 存放1                                                   */
/*==============================================================*/
create table 存放1 
(
   零件号                  integer                        not null,
   仓库号                  integer                        not null,
   constraint PK_存放1 primary key clustered (零件号, 仓库号)
);

/*==============================================================*/
/* Index: 存放1_PK                                                */
/*==============================================================*/
create unique clustered index 存放1_PK on 存放1 (
零件号 ASC,
仓库号 ASC
);

/*==============================================================*/
/* Index: 存放1_FK                                                */
/*==============================================================*/
create index 存放1_FK on 存放1 (
零件号 ASC
);

/*==============================================================*/
/* Index: 存放4_FK                                                */
/*==============================================================*/
create index 存放4_FK on 存放1 (
仓库号 ASC
);

/*==============================================================*/
/* Table: 存放2                                                   */
/*==============================================================*/
create table 存放2 
(
   原材料号                 integer                        not null,
   仓库号                  integer                        not null,
   constraint PK_存放2 primary key clustered (原材料号, 仓库号)
);

/*==============================================================*/
/* Index: 存放2_PK                                                */
/*==============================================================*/
create unique clustered index 存放2_PK on 存放2 (
原材料号 ASC,
仓库号 ASC
);

/*==============================================================*/
/* Index: 存放2_FK                                                */
/*==============================================================*/
create index 存放2_FK on 存放2 (
原材料号 ASC
);

/*==============================================================*/
/* Index: 存放3_FK                                                */
/*==============================================================*/
create index 存放3_FK on 存放2 (
仓库号 ASC
);

/*==============================================================*/
/* Table: 组成                                                    */
/*==============================================================*/
create table 组成 
(
   产品号                  integer                        not null,
   零件号                  integer                        not null,
   constraint PK_组成 primary key clustered (产品号, 零件号)
);

/*==============================================================*/
/* Index: 组成_PK                                                 */
/*==============================================================*/
create unique clustered index 组成_PK on 组成 (
产品号 ASC,
零件号 ASC
);

/*==============================================================*/
/* Index: 组成_FK                                                 */
/*==============================================================*/
create index 组成_FK on 组成 (
产品号 ASC
);

/*==============================================================*/
/* Index: 组成2_FK                                                */
/*==============================================================*/
create index 组成2_FK on 组成 (
零件号 ASC
);

/*==============================================================*/
/* Table: 零件                                                    */
/*==============================================================*/
create table 零件 
(
   零件号                  integer                        not null,
   零件名                  varchar(20)                    null,
   constraint PK_零件 primary key (零件号)
);

/*==============================================================*/
/* Index: 零件_PK                                                 */
/*==============================================================*/
create unique index 零件_PK on 零件 (
零件号 ASC
);

alter table 制造
   add constraint FK_制造_制造_原材料 foreign key (原材料号)
      references 原材料 (原材料号)
      on update restrict
      on delete restrict;

alter table 制造
   add constraint FK_制造_制造2_零件 foreign key (零件号)
      references 零件 (零件号)
      on update restrict
      on delete restrict;

alter table 存放1
   add constraint FK_存放1_存放1_零件 foreign key (零件号)
      references 零件 (零件号)
      on update restrict
      on delete restrict;

alter table 存放1
   add constraint FK_存放1_存放4_仓库 foreign key (仓库号)
      references 仓库 (仓库号)
      on update restrict
      on delete restrict;

alter table 存放2
   add constraint FK_存放2_存放2_原材料 foreign key (原材料号)
      references 原材料 (原材料号)
      on update restrict
      on delete restrict;

alter table 存放2
   add constraint FK_存放2_存放3_仓库 foreign key (仓库号)
      references 仓库 (仓库号)
      on update restrict
      on delete restrict;

alter table 组成
   add constraint FK_组成_组成_产品 foreign key (产品号)
      references 产品 (产品号)
      on update restrict
      on delete restrict;

alter table 组成
   add constraint FK_组成_组成2_零件 foreign key (零件号)
      references 零件 (零件号)
      on update restrict
      on delete restrict;
