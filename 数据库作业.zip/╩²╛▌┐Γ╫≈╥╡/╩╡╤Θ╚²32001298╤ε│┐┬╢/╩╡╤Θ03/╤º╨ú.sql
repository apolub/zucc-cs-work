if exists(select 1 from sys.sysforeignkey where role='FK_学生_RELATIONS_教员') then
    alter table 学生
       delete foreign key FK_学生_RELATIONS_教员
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_学生_RELATIONS_班级') then
    alter table 学生
       delete foreign key FK_学生_RELATIONS_班级
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_教员_RELATIONS_教研室') then
    alter table 教员
       delete foreign key FK_教员_RELATIONS_教研室
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_班级_RELATIONS_系') then
    alter table 班级
       delete foreign key FK_班级_RELATIONS_系
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_选修_选修_学生') then
    alter table 选修
       delete foreign key FK_选修_选修_学生
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_选修_选修2_课程') then
    alter table 选修
       delete foreign key FK_选修_选修2_课程
end if;

drop index if exists 学生.Relationship_4_FK;

drop index if exists 学生.Relationship_3_FK;

drop index if exists 学生.学生_PK;

drop table if exists 学生;

drop index if exists 教员.Relationship_1_FK;

drop index if exists 教员.教员_PK;

drop table if exists 教员;

drop index if exists 教研室.教研室_PK;

drop table if exists 教研室;

drop index if exists 班级.Relationship_2_FK;

drop index if exists 班级.班级_PK;

drop table if exists 班级;

drop index if exists 系.系_PK;

drop table if exists 系;

drop index if exists 课程.课程_PK;

drop table if exists 课程;

drop index if exists 选修.选修2_FK;

drop index if exists 选修.选修_FK;

drop index if exists 选修.选修_PK;

drop table if exists 选修;

/*==============================================================*/
/* Table: 学生                                                    */
/*==============================================================*/
create table 学生 
(
   学号                   integer                        not null,
   班级号                  integer                        null,
   职工号                  integer                        null,
   姓名                   varchar(30)                    null,
   学历                   varchar(100)                   null,
   constraint PK_学生 primary key (学号)
);

/*==============================================================*/
/* Index: 学生_PK                                                 */
/*==============================================================*/
create unique index 学生_PK on 学生 (
学号 ASC
);

/*==============================================================*/
/* Index: Relationship_3_FK                                     */
/*==============================================================*/
create index Relationship_3_FK on 学生 (
职工号 ASC
);

/*==============================================================*/
/* Index: Relationship_4_FK                                     */
/*==============================================================*/
create index Relationship_4_FK on 学生 (
班级号 ASC
);

/*==============================================================*/
/* Table: 教员                                                    */
/*==============================================================*/
create table 教员 
(
   职工号                  integer                        not null,
   教研编号                 integer                        null,
   姓名                   varchar(30)                    null,
   职称                   varchar(50)                    null,
   constraint PK_教员 primary key (职工号)
);

/*==============================================================*/
/* Index: 教员_PK                                                 */
/*==============================================================*/
create unique index 教员_PK on 教员 (
职工号 ASC
);

/*==============================================================*/
/* Index: Relationship_1_FK                                     */
/*==============================================================*/
create index Relationship_1_FK on 教员 (
教研编号 ASC
);

/*==============================================================*/
/* Table: 教研室                                                   */
/*==============================================================*/
create table 教研室 
(
   教研编号                 integer                        not null,
   教研室                  varchar(20)                    null,
   constraint PK_教研室 primary key (教研编号)
);

/*==============================================================*/
/* Index: 教研室_PK                                                */
/*==============================================================*/
create unique index 教研室_PK on 教研室 (
教研编号 ASC
);

/*==============================================================*/
/* Table: 班级                                                    */
/*==============================================================*/
create table 班级 
(
   班级号                  integer                        not null,
   系编号                  integer                        null,
   班级名                  varchar(50)                    null,
   constraint PK_班级 primary key (班级号)
);

/*==============================================================*/
/* Index: 班级_PK                                                 */
/*==============================================================*/
create unique index 班级_PK on 班级 (
班级号 ASC
);

/*==============================================================*/
/* Index: Relationship_2_FK                                     */
/*==============================================================*/
create index Relationship_2_FK on 班级 (
系编号 ASC
);

/*==============================================================*/
/* Table: 系                                                     */
/*==============================================================*/
create table 系 
(
   系编号                  integer                        not null,
   系名                   varchar(30)                    null,
   constraint PK_系 primary key (系编号)
);

/*==============================================================*/
/* Index: 系_PK                                                  */
/*==============================================================*/
create unique index 系_PK on 系 (
系编号 ASC
);

/*==============================================================*/
/* Table: 课程                                                    */
/*==============================================================*/
create table 课程 
(
   课程号                  integer                        not null,
   课程名                  varchar(50)                    null,
   constraint PK_课程 primary key (课程号)
);

/*==============================================================*/
/* Index: 课程_PK                                                 */
/*==============================================================*/
create unique index 课程_PK on 课程 (
课程号 ASC
);

/*==============================================================*/
/* Table: 选修                                                    */
/*==============================================================*/
create table 选修 
(
   学号                   integer                        not null,
   课程号                  integer                        not null,
   constraint PK_选修 primary key clustered (学号, 课程号)
);

/*==============================================================*/
/* Index: 选修_PK                                                 */
/*==============================================================*/
create unique clustered index 选修_PK on 选修 (
学号 ASC,
课程号 ASC
);

/*==============================================================*/
/* Index: 选修_FK                                                 */
/*==============================================================*/
create index 选修_FK on 选修 (
学号 ASC
);

/*==============================================================*/
/* Index: 选修2_FK                                                */
/*==============================================================*/
create index 选修2_FK on 选修 (
课程号 ASC
);

alter table 学生
   add constraint FK_学生_RELATIONS_教员 foreign key (职工号)
      references 教员 (职工号)
      on update restrict
      on delete restrict;

alter table 学生
   add constraint FK_学生_RELATIONS_班级 foreign key (班级号)
      references 班级 (班级号)
      on update restrict
      on delete restrict;

alter table 教员
   add constraint FK_教员_RELATIONS_教研室 foreign key (教研编号)
      references 教研室 (教研编号)
      on update restrict
      on delete restrict;

alter table 班级
   add constraint FK_班级_RELATIONS_系 foreign key (系编号)
      references 系 (系编号)
      on update restrict
      on delete restrict;

alter table 选修
   add constraint FK_选修_选修_学生 foreign key (学号)
      references 学生 (学号)
      on update restrict
      on delete restrict;

alter table 选修
   add constraint FK_选修_选修2_课程 foreign key (课程号)
      references 课程 (课程号)
      on update restrict
      on delete restrict;
