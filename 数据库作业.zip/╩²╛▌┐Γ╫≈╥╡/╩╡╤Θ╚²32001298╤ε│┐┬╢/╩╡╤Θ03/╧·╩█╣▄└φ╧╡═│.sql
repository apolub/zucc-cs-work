if exists(select 1 from sys.sysforeignkey where role='FK_商店_聘用_职工') then
    alter table 商店
       delete foreign key FK_商店_聘用_职工
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_工作_工作_职工') then
    alter table 工作
       delete foreign key FK_工作_工作_职工
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_工作_工作2_商店') then
    alter table 工作
       delete foreign key FK_工作_工作2_商店
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_销售_销售_商店') then
    alter table 销售
       delete foreign key FK_销售_销售_商店
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_销售_销售2_商品') then
    alter table 销售
       delete foreign key FK_销售_销售2_商品
end if;

drop index if exists 商品.商品_PK;

drop table if exists 商品;

drop index if exists 商店.聘用_FK;

drop index if exists 商店.商店_PK;

drop table if exists 商店;

drop index if exists 工作.工作2_FK;

drop index if exists 工作.工作_FK;

drop index if exists 工作.工作_PK;

drop table if exists 工作;

drop index if exists 职工.职工_PK;

drop table if exists 职工;

drop index if exists 销售.销售2_FK;

drop index if exists 销售.销售_FK;

drop index if exists 销售.销售_PK;

drop table if exists 销售;

/*==============================================================*/
/* Table: 商品                                                    */
/*==============================================================*/
create table 商品 
(
   商品号                  char(10)                       not null,
   商品名                  char(10)                       null,
   规格                   char(10)                       null,
   单价                   char(10)                       null,
   constraint PK_商品 primary key (商品号)
);

/*==============================================================*/
/* Index: 商品_PK                                                 */
/*==============================================================*/
create unique index 商品_PK on 商品 (
商品号 ASC
);

/*==============================================================*/
/* Table: 商店                                                    */
/*==============================================================*/
create table 商店 
(
   商店编号                 integer                        not null,
   职工编号                 integer                        not null,
   商店名                  varchar(50)                    null,
   地址                   varchar(100)                   null,
   constraint PK_商店 primary key (商店编号)
);

/*==============================================================*/
/* Index: 商店_PK                                                 */
/*==============================================================*/
create unique index 商店_PK on 商店 (
商店编号 ASC
);

/*==============================================================*/
/* Index: 聘用_FK                                                 */
/*==============================================================*/
create index 聘用_FK on 商店 (
职工编号 ASC
);

/*==============================================================*/
/* Table: 工作                                                    */
/*==============================================================*/
create table 工作 
(
   职工编号                 integer                        not null,
   商店编号                 integer                        not null,
   聘期                   date                           null,
   月薪                   varchar(20)                    null,
   constraint PK_工作 primary key clustered (职工编号, 商店编号)
);

/*==============================================================*/
/* Index: 工作_PK                                                 */
/*==============================================================*/
create unique clustered index 工作_PK on 工作 (
职工编号 ASC,
商店编号 ASC
);

/*==============================================================*/
/* Index: 工作_FK                                                 */
/*==============================================================*/
create index 工作_FK on 工作 (
职工编号 ASC
);

/*==============================================================*/
/* Index: 工作2_FK                                                */
/*==============================================================*/
create index 工作2_FK on 工作 (
商店编号 ASC
);

/*==============================================================*/
/* Table: 职工                                                    */
/*==============================================================*/
create table 职工 
(
   职工编号                 integer                        not null,
   姓名                   varchar(30)                    null,
   性别                   varchar(20)                    null,
   业绩                   varchar(200)                   null,
   constraint PK_职工 primary key (职工编号)
);

/*==============================================================*/
/* Index: 职工_PK                                                 */
/*==============================================================*/
create unique index 职工_PK on 职工 (
职工编号 ASC
);

/*==============================================================*/
/* Table: 销售                                                    */
/*==============================================================*/
create table 销售 
(
   商店编号                 integer                        not null,
   商品号                  char(10)                       not null,
   月销量                  varchar(20)                    null,
   constraint PK_销售 primary key clustered (商店编号, 商品号)
);

/*==============================================================*/
/* Index: 销售_PK                                                 */
/*==============================================================*/
create unique clustered index 销售_PK on 销售 (
商店编号 ASC,
商品号 ASC
);

/*==============================================================*/
/* Index: 销售_FK                                                 */
/*==============================================================*/
create index 销售_FK on 销售 (
商店编号 ASC
);

/*==============================================================*/
/* Index: 销售2_FK                                                */
/*==============================================================*/
create index 销售2_FK on 销售 (
商品号 ASC
);

alter table 商店
   add constraint FK_商店_聘用_职工 foreign key (职工编号)
      references 职工 (职工编号)
      on update restrict
      on delete restrict;

alter table 工作
   add constraint FK_工作_工作_职工 foreign key (职工编号)
      references 职工 (职工编号)
      on update restrict
      on delete restrict;

alter table 工作
   add constraint FK_工作_工作2_商店 foreign key (商店编号)
      references 商店 (商店编号)
      on update restrict
      on delete restrict;

alter table 销售
   add constraint FK_销售_销售_商店 foreign key (商店编号)
      references 商店 (商店编号)
      on update restrict
      on delete restrict;

alter table 销售
   add constraint FK_销售_销售2_商品 foreign key (商品号)
      references 商品 (商品号)
      on update restrict
      on delete restrict;
