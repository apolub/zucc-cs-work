drop table if exists Relationship_1;

drop table if exists book;

drop table if exists press;

drop table if exists reader;

/*==============================================================*/
/* Table: Relationship_1                                        */
/*==============================================================*/
create table Relationship_1
(
   readerNum            numeric(20,0) not null,
   primary key (readerNum)
);

/*==============================================================*/
/* Table: book                                                  */
/*==============================================================*/
create table book
(
   pressName            varchar(20),
   bookNum              numeric(20,0) not null,
   number               numeric(200,0),
   place                varchar(50),
   kind                 varchar(20)
);

/*==============================================================*/
/* Table: press                                                 */
/*==============================================================*/
create table press
(
   pressName            varchar(20) not null,
   tele                 numeric(20,0),
   postcode             numeric(20,0),
   email                varchar(50),
   primary key (pressName)
);

/*==============================================================*/
/* Table: reader                                                */
/*==============================================================*/
create table reader
(
   readerNum            numeric(20,0) not null,
   name                 varchar(20),
   unit                 varchar(20),
   borrowDay            date,
   returnDay            date,
   primary key (readerNum)
);

alter table Relationship_1 add constraint FK_Relationship_1 foreign key (readerNum)
      references reader (readerNum) on delete restrict on update restrict;

alter table Relationship_1 add constraint FK_Relationship_2 foreign key ()
      references book on delete restrict on update restrict;

alter table book add constraint FK_Relationship_3 foreign key (pressName)
      references press (pressName) on delete restrict on update restrict;
