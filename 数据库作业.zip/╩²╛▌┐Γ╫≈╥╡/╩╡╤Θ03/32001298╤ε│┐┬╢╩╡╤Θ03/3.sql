drop table if exists device;

drop table if exists organization;

drop table if exists project;

drop table if exists provider;

drop table if exists worker;

/*==============================================================*/
/* Table: device                                                */
/*==============================================================*/
create table device
(
   deviceID             numeric(20,0) not null,
   deviceName           varchar(20),
   devicePlace          varchar(20),
   primary key (deviceID)
);

/*==============================================================*/
/* Table: organization                                          */
/*==============================================================*/
create table organization
(
   organizationName     varchar(20) not null,
   tele                 numeric(20,0)
);

/*==============================================================*/
/* Table: project                                               */
/*==============================================================*/
create table project
(
   projectName          varchar(20) not null,
   place                varchar(10)
);

/*==============================================================*/
/* Table: provider                                              */
/*==============================================================*/
create table provider
(
   deviceID             numeric(20,0) not null,
   providerName         varchar(20),
   tele                 numeric(20,0),
   primary key (deviceID)
);

/*==============================================================*/
/* Table: worker                                                */
/*==============================================================*/
create table worker
(
   workerID             numeric(20,0) not null,
   workerName           varchar(20),
   gender               varchar(5)
);

alter table provider add constraint FK_provider foreign key ()
      references project on delete restrict on update restrict;

alter table provider add constraint FK_provider2 foreign key (deviceID)
      references device (deviceID) on delete restrict on update restrict;

alter table worker add constraint FK_Relationship_1 foreign key ()
      references organization on delete restrict on update restrict;

alter table worker add constraint FK_Relationship_2 foreign key ()
      references project on delete restrict on update restrict;
