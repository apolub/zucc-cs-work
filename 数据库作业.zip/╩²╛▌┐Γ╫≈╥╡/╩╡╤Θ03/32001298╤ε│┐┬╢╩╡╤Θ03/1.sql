drop table if exists Relationship_1;

drop table if exists guider;

drop table if exists line;

drop table if exists scenic;

drop table if exists team;

/*==============================================================*/
/* Table: Relationship_1                                        */
/*==============================================================*/
create table Relationship_1
(
   scenicID             numeric(20,0) not null,
   lineID               numeric(20,0) not null,
   primary key (scenicID, lineID)
);

/*==============================================================*/
/* Table: guider                                                */
/*==============================================================*/
create table guider
(
   guiderID             numeric(20,0) not null,
   lineID               numeric(20,0),
   guiderName           varchar(20),
   level                numeric(5,0),
   primary key (guiderID)
);

/*==============================================================*/
/* Table: line                                                  */
/*==============================================================*/
create table line
(
   lineID               numeric(20,0) not null,
   lineName             varchar(20),
   lineDes              varchar(200),
   primary key (lineID)
);

/*==============================================================*/
/* Table: scenic                                                */
/*==============================================================*/
create table scenic
(
   scenicID             numeric(20,0) not null,
   scenicName           varchar(20),
   place                varchar(20),
   description          varchar(20),
   primary key (scenicID)
);

/*==============================================================*/
/* Table: team                                                  */
/*==============================================================*/
create table team
(
   teamID               numeric(20,0) not null,
   lineID               numeric(20,0),
   teamNum              numeric(100,0),
   DayStart             date,
   DayEnd               date,
   primary key (teamID)
);

alter table Relationship_1 add constraint FK_Relationship_1 foreign key (scenicID)
      references scenic (scenicID) on delete restrict on update restrict;

alter table Relationship_1 add constraint FK_Relationship_4 foreign key (lineID)
      references line (lineID) on delete restrict on update restrict;

alter table guider add constraint FK_Relationship_2 foreign key (lineID)
      references line (lineID) on delete restrict on update restrict;

alter table team add constraint FK_Relationship_3 foreign key (lineID)
      references line (lineID) on delete restrict on update restrict;
