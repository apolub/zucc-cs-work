import numpy as np
import pandas as pd
from scipy.optimize import minimize

#激活函数
def sigmoid(z):
    return 1 / (1 + np.exp(-z))

#前向传播来计算预测结果
def forward_propagate(X, theta1, theta2):
    a1 =np.insert(X, 0, values=np.ones(m), axis=1) #给X矩阵插入一行1元素
    z2 =a1 * theta1.T
    a2 =np.insert(sigmoid(z2), 0, values=np.ones(m), axis=1)  #注意插入1元素
    z3 = a2 * theta2.T
    h = sigmoid(z3)
    return a1, z2, a2, z3, h

def cost( input_size, hidden_size, num_labels,X, y, lamda): 
    # 获取神经网络参数
    Theta1 = np.array(pd.read_csv("D:\python\dataMining\week10\Theta1.csv"))
    Theta2 = np.array(pd.read_csv("D:\python\dataMining\week10\Theta2.csv"))
    theta1 = np.matrix(np.reshape(Theta1[hidden_size * (input_size + 1):], (num_labels, (hidden_size + 1))))
    theta2 = np.matrix(np.reshape(Theta2[hidden_size * (input_size + 1):], (num_labels, (hidden_size + 1))))

    # 调用前面写好的前项传播函数
    a1, z2, a2, z3, h = forward_propagate(X, theta1, theta2)
    
    # 初始化代价函数
    J = 0
    
    #根据公式计算代价函数
    for i in range(m):  #遍历每个样本
        first_term =np.multiply(-y[i,:], np.log(h[i,:]))
        second_term = np.multiply((1 - y[i,:]), np.log(1 - h[i,:]))
        J += np.sum(first_term - second_term)
    J = J / m
    # 计算代价函数的正则化部分
    J += (float(lamda) / (2 * m)) * (np.sum(np.power(theta1[:,1:], 2)) + np.sum(np.power(theta2[:,1:], 2)))
    
    return J

# 初始化设置
input_size = 400
hidden_size = 25
num_labels = 10
lamda = 1


data  = pd.read_csv("D:\python\dataMining\week10\X_data.csv")
data = np.array(data)
m,n = data.shape
x=data[:,0:n]
y=data[:,-1]




#预测
fmin = minimize(fun=forward_propagate,x0 = 0.05, args=(input_size, hidden_size, num_labels, x, y, lamda), 
                method='TNC', jac=True, options={'maxiter': 250})
X = np.matrix(x)
# 将参数数组解开为每个层的参数矩阵
Theta1 = np.array(pd.read_csv("D:\python\dataMining\week10\Theta1.csv"))
Theta2 = np.array(pd.read_csv("D:\python\dataMining\week10\Theta2.csv"))
theta1 = np.matrix(np.reshape(Theta1[hidden_size * (input_size + 1):], (num_labels, (hidden_size + 1))))
theta2 = np.matrix(np.reshape(Theta2[hidden_size * (input_size + 1):], (num_labels, (hidden_size + 1))))
a1, z2, a2, z3, h = forward_propagate(x, theta1, theta2)

y_pred = np.array(pd.read_csv("D:\python\dataMining\week10\y_label.csv"))
correct = [1 if a == b else 0 for (a, b) in zip(y_pred, y)]
accuracy = (sum(map(int, correct)) / float(len(correct)))
print ('accuracy = {0}%'.format(accuracy * 100))

