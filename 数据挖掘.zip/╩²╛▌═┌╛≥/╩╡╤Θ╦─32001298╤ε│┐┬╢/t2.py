import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from numpy import argmax
from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler


class logistic:
    def __init__(self, rate=1e-3, epsilon=1e-5, x=None, y=None):
        self.rate = rate
        self.epsilon = epsilon
        self.X = x
        self.Y = y
        self.w = None
        self.loss_list = []# 损失列表
        self.acc_list = []# 准确列表
        self.__pre__()
        print(self.X.shape, self.w.shape, self.Y.shape)

    def __pre__(self):
        # 标准化 不然后面调用softmax函数会出现RuntimeWarning: overflow encountered in exp即数值太大溢出
        scaler = StandardScaler()
        self.X = scaler.fit_transform(self.X)
        self.X = np.c_[self.X, np.ones((self.X.shape[0], 1))]
        enc = preprocessing.OneHotEncoder()
        self.Y = enc.fit_transform(self.Y).toarray()
        self.w = np.zeros((self.X.shape[1],self.Y.shape[1]))
        

    # softmax函数进行了修改，防止溢出问题
    def softmax(self, x, w):# 多分类
        d = x.dot(w)
        d_max = np.reshape(np.max(d, axis=1),(-1,1))
        return np.exp(d-d_max)/np.sum(np.exp(d-d_max), axis=1, keepdims=True)


    # get 梯度
    def getGradient(self, w):
        g = np.zeros(w.shape)
        prob = self.softmax(self.X, w)
        for i in range(self.X.shape[0]):
            for j in range(self.Y.shape[1]):
                if self.Y[i,j] == 1:
                    g[:,j] -= (1-prob[i,j])*self.X[i]
                else:
                    g[:,j] += prob[i,j]*self.X[i]
        return g

    # 极大似然函数求max 但是这里取负 求min即可
    def loss_func(self, h, y):
        return -np.sum(np.multiply(np.log(h), y))

    # 计算精确度
    def acc_fuc(self, pred, true):
      
        acc = np.mean(np.equal(argmax(pred,1),argmax(true,1)))
        return acc

    def log(self):
        cnt = 0
        loss = np.sum([self.loss_func(self.softmax(self.X[i:i + 1], self.w), self.Y[i:i+1])
                    for i in range(self.X.shape[0])]) / self.Y.shape[0]
        while True:
            cnt += 1
            self.w = self.w - self.rate * self.getGradient(self.w)
           
            lossnew = np.sum([self.loss_func(self.softmax(self.X[i:i + 1], self.w), self.Y[i:i+1])
                           for i in range(self.X.shape[0])]) / self.Y.shape[0]
            self.loss_list.append(lossnew)
            accnew = self.acc_fuc(self.softmax(self.X, self.w), self.Y)
            self.acc_list.append(accnew)
            print('iter_count: ', cnt, 'loss: ', lossnew, ' acc: ', accnew)
            if abs(loss - lossnew) < self.epsilon:
                break
            loss = lossnew
    def plot_loss(self):
        plt.plot(self.loss_list)
        plt.ylabel("loss")
        plt.show()
    def plot_acc(self):
        plt.plot(self.acc_list)
        plt.ylabel('acc')
        plt.show()

if __name__ == '__main__':
    data_x = pd.read_csv("c://python//DataMining//week7//amazon_X.csv", header=None)
    data_y = pd.read_csv("c://python//DataMining//week7//amazon_y.csv", header=None)
    log = logistic(rate=1e-3, epsilon=1e-2, x=data_x.values, y=data_y)
    log.log()
    log.plot_loss()
    log.plot_acc()
