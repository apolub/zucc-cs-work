from sklearn.neighbors import KNeighborsClassifier #k邻近算法模型
from numpy import np
import pandas as pd

data = pd.read.csv("c://python//DataMining//week7/t.csv")
data.y = data[:,-1]
data.x = data[:,1:7]


#实例k邻近模型，指定k值=3
knn = KNeighborsClassifier(n_neighbors=5)

#训练数据
knn.fit(data.x,data.y)

#模型评分
knn.score(data.x,data.y)

#预测
data_pridict=knn.predict(np.array(data[10:11,1:7]))
print("预测值: "data_pridict)


