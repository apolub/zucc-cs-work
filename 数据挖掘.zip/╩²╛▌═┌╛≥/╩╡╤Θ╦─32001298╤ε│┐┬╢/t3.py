import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler


class KNN:
    def __init__(self, k, x, y):
        self.x = x
        self.y = y
        self.k = k
        self.true = 0
        self.__pre__()

    # 标准化数据,去量纲
    def __pre__(self):
        stand = StandardScaler()
        self.x = stand.fit_transform(self.x)

    # 第ii个数据与其他数据的欧式距离
    def getDistance(self, ii):
        data = np.sum((self.x - self.x[ii]) ** 2, axis=1)
        distances = np.concatenate((data.reshape(-1, 1), self.y.reshape(-1, 1)), axis=1)
       

    def getK(self):
        # 所有数据都进行计算
        for j in range(self.x.shape[0]):
            dis = self.getDistance(j)
            dis = sorted(dis, key=lambda cus: cus[0], reverse=False)[1:]
            index = self.k
            for i in range(self.k, len(dis)):
                if dis[i][0] == dis[self.k - 1][0]:
                    index = i
                else:
                    break
            list = dis[:index]
            dict = {}
            for cube in list:
                key = cube[1]
                if key in dict.keys():
                    dict.update({key: dict.get(key) + 1})
                else:
                    dict[key] = 1
            m = max(dict, key=dict.get)
            if m == self.y[j][0]:
                self.true += 1
        return self.true / self.x.shape[0]


if __name__ == '__main__':
    x = pd.read_csv("c://python//DataMining//week7//cancer_X.csv", header=None)
    y = pd.read_csv("c://python//DataMining//week7//cancer_y.csv", header=None)
    for k in range(5,8):
        knn = KNN(k, x.values, y.values)
        print('k=' + str(k) + ',acc=', knn.getK())