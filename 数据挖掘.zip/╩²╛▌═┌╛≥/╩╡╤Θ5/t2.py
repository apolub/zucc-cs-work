from sklearn import utils
import pandas as pd
import numpy as np
from sklearn import tree
from sklearn.model_selection import train_test_split

data =pd.read_csv("c://python//DataMining//week9//german_clean.csv")
data=np.array(data)
data = utils.shuffle(data)

Y = data["class"].value
X = data.drop("class", axis=1).value

#拆分训练集和测试集
Xtrain, Xtest, Ytrain, Ytest = train_test_split(X,Y,test_size=0.3)

 #决策树
# dtc = DecisionTreeClassifier(criterion="entropy", min_samples_leaf=3, max_depth=15)
clf = tree.DecisionTreeClassifier(criterion="entropy",random_state=30 ,splitter="random",max_depth=3,min_samples_leaf=10)
# clf为拟合好的模型
clf = clf.fit(Xtrain, Ytrain)
clf_y_predict = clf.predict(Xtest)
print(clf_y_predict)               #输出预测的标签
score=clf.score(Xtest,Ytest)
print(score)                        #输出预测的准确度