import pandas as pd

data = pd.read_csv("c://python//DataMining//week9//weather_nominal.csv")
# print(data.shape)#行数列数
# print(data.dtypes) #所有列的数据类型
# data.head()  #默认取前五行的数据，数据过多时可以使用

#输出各列的唯一值
# tamp =[]
# for i in data:
#     tamp.append(list(set(data[i].values.tolist())))
    #print(list(set(data[i].values.tolist())))

#标注字典
d1 ={'rainy':1, 'overcast':2, 'sunny':3}
d2 ={'hot':0, 'mild':1, 'cool':2}
d3 ={'normal':0, 'high':1}
d4 ={False:0, True:1}
d5 ={'yes':1, 'no':0}
list1 =[d1,d2,d3,d4,d5]
#获取列名
columns =data.columns.tolist()
#构建单词数据集和标签
for i in range(len(columns)):
    data[columns[i]] = data[columns[i]].map(list1[i])
# print(data)

# 预测
predict=[1,0,1,1,0]

# 返回类别标签
labels=['yes','no']
classes = list(set(data.iloc[:,-1].tolist()))
result=[]
for i in range(len(classes)):
    test_result=[]
    test_data1=data[data['play']==classes[i]]
    P1=test_data1.shape[0]/data.shape[0]
    print("原数据集第"+str(i)+"类的概率：",P1)
    for j in range(len(predict)):
        test_data2=test_data1[test_data1[columns[j]]==predict[j]]
        if test_data2.shape[0]==0:
            P2=1
        else:
            P2 = test_data2.shape[0]/test_data1.shape[0]
        print("在第"+str(i)+"类的条件下"+"x"+str(j)+"的概率：",P2)
        test_result.append(P2)
    print(test_result)
    
    multiply = 1.0
    for k in test_result:
        multiply *=k
    pro = multiply/P1
    print("属于第"+str(i)+"类的概率：",pro)
    result.append(pro)
    print("\n")

print("属于各类的概率：",result)
max_index = result.index(max(result,key = abs))
print("测试结果：属于"+labels[max_index]+"\t概率为:"+str(result[max_index]))
