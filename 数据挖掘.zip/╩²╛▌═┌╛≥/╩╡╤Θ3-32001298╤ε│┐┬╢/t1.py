from importlib.resources import path
import pandas as pd
import  numpy as np

data_read=pd.read_csv('c://python//data mining//week6/telco.csv',engine='python')
list = data_read.values.tolist()
data = np.array(list)

m, n = np.shape(data_read)
x_data = np.ones((m, n+1))
x_data[:, :-1] = np.array(data_read)
y_data = np.ones((m, n+1))
y_data[:, :-1] = np.array(data_read)


        
#梯度下降算法函数,x/y是输入变量，t是参数，alpha是学习率，m是实例，counts梯度下降迭代次数
def gradientDescent(x_data, y_data, t, alpha, m, counts):
    xTrans = x_data.transpose() #矩阵转置
    for i in range(0,counts):
        hypothesis = np.dot(x_data,t) #矩阵相乘
        loss = hypothesis - y_data 
        cost = np.sum(loss **2)/(2 * m)
        print("Iteration %d | Cost: %f" % (i, cost))
        gradient = np.dot(xTrans, loss) / m  
        t = t - alpha * gradient #参数theta的计算，即更新法则
    return t

counts = 100000
alpha = 0.0005 
t = np.ones(n) #初始化
t = gradientDescent(x_data, y_data, t, alpha, m, counts)
print(t)
    
