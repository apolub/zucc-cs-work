from math import log
import numpy as np
import pandas as pd

def sigmoid(x):
    return 1.0/(1+np.exp(-x))

def Lossfunction(x,y,alpha):
    m = np.size(x,1)
    t = 0
    for i in range (m):
      if y(i) == 1:
          t = t - log(sigmoid(np.dot(x[i,0] , alpha)))
      else:
          t = t - log(1 - sigmoid(np.dot(x[i,0] , alpha)))
    return t

def Lossdl1(x,y,alpha):
     m = np.size(y, 1)
     d = np.dot(x , (sigmoid(np.dot(x ,alpha)) - y)) / m
     return d

def Lossdl2(x,y,alpha):
     m = np.size(y, 1)
     n = np.zeros(1, m)
     for i in range(m):
        n[i] = np.dot(sigmoid(np.dot(x[i,0] , alpha)) ,(1 - sigmoid(np.dot(x[i,0] , alpha))))
     a =np.diag(n)
     t = x * a * x / m
     return  t


def newton(x,y,w,alpha,l):
    for i in range (l):
         dl = Lossdl1(w, x, y)
         H = Lossdl2(w, x, y)
         w_next = w - alpha * (np.pinv(H) * dl)
         if Lossfunction(w_next, X, y) < 1e-6 :
              w = w_next
              break
    w = w_next
    return w

X = pd.read_csv('c://python//data mining//week6/telco.csv',engine='python')
list = X.values.tolist()
data = np.array(list)
n = np.shape(list)
x_data = data[:,0:-1]
#填充0
d = pd.DataFrame(data=x_data)
x_data = d.fillna(value=0)
y_data = data[:,-1]
w = np.ones(n)
alpha = 0.05
l = 10000
Newton = newton(x_data,y_data,w,alpha,l)
print("\n迭代:",l,"次",",最大迭代次数: ", w)