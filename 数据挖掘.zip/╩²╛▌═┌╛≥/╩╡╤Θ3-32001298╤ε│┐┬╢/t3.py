from re import L
from turtle import pd
import numpy as np

def sigmoid(x):
    return  1.0/(1+np.exp(-x))

def Lossdl(x,y,thapa):
    m, n = x.shape
    h = sigmoid(x ,thapa)
    dl = (-1.0 / m) * np.sum(y.T * np.log(h + 1e-6)
                               + (1 - y).T * np.log(1 - h + 1e-6))
    return dl

#梯度更新
def gradienreg(x,y,w,thapa,l):
    process = l / 100  # 显示进度
    X = np.mat(X)
    y = np.mat(y)
    m, n = X.shape
    thapa = np.ones((n, 1))
    loss = 1
    iter = 0
    while (iter < L):
        loss = Lossdl(X, thapa, y)
        # 梯度的下降法
        h = sigmoid(X ,thapa)  # 预测值
        error = h - y  # 误差项
        grad = (1.0 / m) * (X.T , error ) # 梯度
        thapa = thapa - thapa * grad

        if (iter % process == 0):
            print("|", end="")
        if np.all(np.absolute(grad) <= w):
            break
        iter += 1
    print("\n迭代:", iter, "次", "  最大迭代次数: ", l, "损失: ", loss)
    return thapa

X = pd.read_csv('c://python//data mining//week6/telco.csv',engine='python')
list = X.values.tolist()
data = np.array(list)
n = np.shape(list)
x_data = data[:,0:-1]
#填充0
d = pd.DataFrame(data=x_data)
x_data = d.fillna(value=0)
y_data = data[:,-1]
w = np.ones(n)
thapa = 0.05
l = 10000
gradienreg(x_data,y_data,w,thapa,l)