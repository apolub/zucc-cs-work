


import numpy as np
 
def Guss_Selbi(a, b, x, g):  
    x = x.astype(float) 
    m, n = a.shape
    times = 0  # ��������
    if (m < n):
        print("There is a ��ռ䡣")  
    else:
        while True:
            for i in range(n):
                s1 = 0
                tempx = x.copy() 
                for j in range(n):
                    if i != j:
                        s1 += x[j] * a[i][j]
                x[i] = (b[i] - s1) / a[i][i]
                times += 1   
            gap = max(abs(x - tempx)) 
 
            if gap < g:  
                break
 
            elif times > 10000: 
                break
              
 
    print(times)
    print(x)
 
 

    a = np.array([[4,-1,0,-1,0,0],[-1,4,-1,0,-1,0],[0,-1,4,-1,0,-1],[-1,0,-1,4,-1,0],[0,-1,0,-1,4,-1],[0,0,-1,0,-1,4]])
    b = np.array([0],[5],[-2],[5],[-2],[6])
    x = np.array([0, 0, 0,0,0,0,0])  
    g = 1e-6  # ����Ϊ0.000001
    Guss_Selbi(a, b, x, g)


