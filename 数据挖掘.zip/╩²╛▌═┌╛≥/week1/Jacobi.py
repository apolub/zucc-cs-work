
def Jacobi(mx,mr,n=100,c=0.0001):
    if len(mx) == len(mr): 
        x = [] 
        for i in range(len(mr)):
            x.append([0])
        count = 0 
        while count < n:
            nx = [] 
            for i in range(len(x)):
                nxi = mr[i][0]
                for j in range(len(mx[i])):
                    if j!=i:
                        nxi = nxi+(-mx[i][j])*x[j][0]
                nxi = nxi/mx[i][i]
                nx.append([nxi]) 
            lc = [] 
            for i in range(len(x)):
                lc.append(abs(x[i][0]-nx[i][0]))
            if max(lc) < c:
                return nx 
            x = nx
            count = count + 1
        return False 
    else:
        return False
 
mx = [[4,-1,0,-1,0,0],[-1,4,-1,0,-1,0],[0,-1,4,-1,0,-1],[-1,0,-1,4,-1,0],[0,-1,0,-1,4,-1],[0,0,-1,0,-1,4]]
 
mr = [[0],[5],[-2],[5],[-2],[6]]
print(Jacobi(mx,mr,100,0.00001))
